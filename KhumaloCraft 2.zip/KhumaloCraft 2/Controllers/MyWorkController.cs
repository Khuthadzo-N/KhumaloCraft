﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using KhumaloCraft.Models;
// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace KhumaloCraft.Controllers
{

    public class MyWorkController : Controller
    {
        public IActionResult Index()
        {
            var craftwork = new List<Craftwork>
        {
                new Craftwork { Name = "Handcrafted Necklace", Description = "A beautiful necklace meticulously crafted by skilled artisans, perfect for any occasion.", Price = 500, ImageUrl = "/images/necklace.jpg" },
new Craftwork { Name = "Handmade Basket", Description = "An elegant basket woven by skilled artisans, ideal for home decor or storage.", Price = 800, ImageUrl = "/images/basket.jpg" },
new Craftwork { Name = "Rope Lantern", Description = "A charming rope lantern handcrafted by skilled artisans, adding a rustic touch to your space.", Price = 150, ImageUrl = "/images/Rope Lantern.jpg" },
new Craftwork { Name = "Handcrafted Tea Set", Description = "A beautifully designed tea set crafted by skilled artisans, perfect for tea lovers.", Price = 1200, ImageUrl = "/images/Handicrafted Tea Set.jpg" },
new Craftwork { Name = "Iris Decorative Handicraft Wall", Description = "A stunning decorative wall piece featuring an iris design, handcrafted by skilled artisans.", Price = 1000, ImageUrl = "/images/Iris Decorative Handicarft Wall.jpg" },
new Craftwork { Name = "Feather and Leaf Bracelet", Description = "A delicate bracelet featuring feather and leaf designs, skillfully handcrafted for a unique look.", Price = 111, ImageUrl = "/images/Feather and Leaf bracelet.png" },
new Craftwork { Name = "Jewellery Box", Description = "An elegant jewellery box, carefully crafted to store your precious accessories.", Price = 2000, ImageUrl = "/images/Jewellery Box.jpg" },
new Craftwork { Name = "Jewellery Set", Description = "A stunning jewellery set, handcrafted by artisans to add elegance to your attire.", Price = 350, ImageUrl = "/images/Jewellery Set.jpg" },
new Craftwork { Name = "White Beaded Earrings", Description = "Beautiful white beaded earrings, crafted by skilled artisans to complement any outfit.", Price = 200, ImageUrl = "/images/White beaded Earrings.jpg" },
new Craftwork { Name = "Hairband", Description = "A stylish hairband, handcrafted by artisans, perfect for adding a touch of elegance to your hairstyle.", Price = 150, ImageUrl = "/images/Hairband.jpg" },
new Craftwork { Name = "Hair Elastic", Description = "A durable and stylish hair elastic, handcrafted by artisans, ideal for everyday use.", Price = 100, ImageUrl = "/images/Hair elastic.jpg" },
new Craftwork { Name = "Wool Handbag", Description = "A chic wool handbag, skillfully crafted by artisans, perfect for carrying your essentials in style.", Price = 600, ImageUrl = "/images/Wool handbag.jpg" },
new Craftwork { Name = "Arty Handbag", Description = "An artistic handbag, beautifully handcrafted by artisans, adding a unique touch to your collection.", Price = 650, ImageUrl = "/images/Arty Hang bag.jpg" },
new Craftwork { Name = "Tie Dye Shirt", Description = "A vibrant tie dye shirt, handcrafted by artisans, perfect for a casual and colorful look.", Price = 150, ImageUrl = "/images/Tye Dye shirt.jpg" },
new Craftwork { Name = "Beaded Bralets", Description = "Stylish beaded bralets, meticulously handcrafted by artisans, perfect for adding a bohemian touch to your wardrobe.", Price = 400, ImageUrl = "/images/Beaded bralets.jpg" },
new Craftwork { Name = "Birds on a Tree", Description = "A beautiful wall art piece featuring birds on a tree, handcrafted by skilled artisans.", Price = 700, ImageUrl = "/images/Birds on a tree.jpg" },
new Craftwork { Name = "Butterfly Wall Art", Description = "An exquisite butterfly wall art piece, carefully handcrafted by artisans to enhance your home decor.", Price = 900, ImageUrl = "/images/Butterfly wall art.jpg" },
new Craftwork { Name = "House Wall Art", Description = "A charming house wall art piece, skillfully handcrafted by artisans to bring a cozy feel to your home.", Price = 500, ImageUrl = "/images/House wall art.jpg" }

        };

            return View(craftwork);

        }
        [HttpPost]
        public IActionResult AddToCart(int productId, int quantity)
        {
            // Handle the logic for adding the product to the cart
            ViewBag.Message = $"Product {productId} with quantity {quantity} added to cart.";
            return RedirectToAction("Index");
        }
    }

}

